package vo;

public class TreatmentVO {
	private int id, patient_id, cost_get;
	private String step, kind;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPatient_id() {
		return patient_id;
	}
	public void setPatient_id(int patient_id) {
		this.patient_id = patient_id;
	}
	public int getCost_get() {
		return cost_get;
	}
	public void setCost_get(int cost_get) {
		this.cost_get = cost_get;
	}
	public String getStep() {
		return step;
	}
	public void setStep(String step) {
		this.step = step;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	
	
}
